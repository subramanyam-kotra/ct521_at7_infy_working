# flake8: noqa
# flags relating to adding a monitor
flags = {
    "disable_ht40":       0x800,
    "disable_ht80":   0x8000000,
    "ht160_enable": 0x100000000,
}
default_flags_mask = 0xFFFFFFFFFFFF
