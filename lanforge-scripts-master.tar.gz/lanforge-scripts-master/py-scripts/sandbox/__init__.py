"""LANforge Python scripts sandbox.

Experimental and incomplete LANforge scripts (Python or otherwise).
Formerly used as a staging area for new scripts.
"""
